angular.module('app',['ngRoute', 'mgcrea.ngStrap'])
.config(function($locationProvider, $routeProvider){

        $locationProvider.html5Mode(true);
        $routeProvider.when('/', {
            templateUrl: 'users/templates/userHome.html',
            controller: 'userHomeController'
        });

        $routeProvider.when('/user/new', {
            templateUrl: 'users/templates/userNew.html',
            controller: 'userNewController'
        })
});