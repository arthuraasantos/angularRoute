var app = angular.module('app');

app.controller('userNewController', function(){

});